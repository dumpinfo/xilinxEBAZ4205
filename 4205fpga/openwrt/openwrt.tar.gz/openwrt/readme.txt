1.burn openwrt.img to a sdcard.
2.replace boot.bin with new one.
